
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.9.3'
version = '1.9.3'
full_version = '1.9.3'
git_revision = 'edb902cdc6573553afcf11047ecdfb447e444322'
release = True

if not release:
    version = full_version
