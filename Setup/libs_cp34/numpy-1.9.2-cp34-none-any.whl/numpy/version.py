
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.9.2'
version = '1.9.2'
full_version = '1.9.2'
git_revision = '762c6f15bf57506e21239a4dd68192e4da6014f7'
release = True

if not release:
    version = full_version
